﻿using System;

namespace amantini.davide._5h.PrimoEF
{
    class Program
    {
        static void Main(string[] args)
        {
            // Apro il db
            DbPersone db = new();

            // Aggiungo una nuova persona
            for(int i = 0; i < 1000; i++)
            {
                db.Persone.Add(new Persona 
                { 
                    Nome = "Davide", 
                    Cognome = "Amantini", 
                    Email = "davide.amantini@studenti.ittsrimini.edu.it"
                });
            }

            db.SaveChanges();
        }
    }
}
